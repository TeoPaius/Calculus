x = [100,121,144];
values = [10,11,12];

format long;
res = lag_bar(115,x,values);
fprintf("sqr(115)= %.2f\n", res)

