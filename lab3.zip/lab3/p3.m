x = linspace(0,10,100);
values = arrayfun(@(t) (1 + cos(pi*t)) / (1 + t), x) ;

plot(x, values);
hold on

xTest = linspace(1,9,20);

res = arrayfun(@(t) lag_bar(t, x, values), xTest);

plot(xTest, res, 'o');

% 
% format long;
% res = lag_bar(1955,x,values);
% fprintf("year 1955: %.2f\n", res)
% 
% 
% res = lag_bar(1995,x,values);
% fprintf("year 1995: %.2f\n", res)
